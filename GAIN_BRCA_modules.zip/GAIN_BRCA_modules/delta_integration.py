#Import packages
import pandas as pd
import math
import numpy as np

def int_Delta1(miRNA, mRNA, Int1):
	#Extract gene name
	mrna_list = mRNA.index.tolist()

	#create empty data frame
	df = pd.DataFrame()
	delta1 = pd.DataFrame()

	##########################################################################################
	for i in mrna_list:
		#print ("============== gene ==========", i)
		#Extract gene expression values
		mrna_temp = mRNA.loc[i]
	
		######################################################################################
	
		#print("Calculation of miRNAs having interaction with", i)	
		if i in Int1.index.tolist():
			#print("Yes miRNA FOR ", i)
			##################################################################################
			if isinstance(Int1.loc[i]["Mirna"], str) == True:
				mir_list =[]
				mir_list.append(Int1.loc[i]["Mirna"])
			else:
				mir_list = Int1.loc[i]["Mirna"].tolist()
	
			## check in miRNA expression file
			for j in mir_list:
				if j in miRNA.index.tolist():
					mirna = miRNA.loc[j]
					mirna_exp = pd.Series(mirna.apply(lambda x : 1/math.e ** (1.5*(math.log(x+1,2))))).mul(mrna_temp)
					df = pd.concat([df, mirna_exp], axis = 1).mean(axis=1)
				else:
					None
		else:
			#print("NO miRNA FOR ", i )
			df = mrna_temp
		delta1 = pd.concat([delta1, df], axis = 1)
		#print(delta1.shape)
	delta1.columns = [mrna_list]
	#delta1.to_csv(r"transformed_mirna.tsv", sep = "\t")
	return delta1


def int_Delta2(methyl, mRNA, Int2):
	#Extract gene name
	mrna_list = mRNA.index.tolist()
	#print(mrna_list)

	#create empty data frame
	df = pd.DataFrame()
	delta2 = pd.DataFrame()

	##########################################################################################
	for i in mrna_list:
		#print ("============== gene ==========", i)
		#Extract gene expression values
		mrna_temp = mRNA.loc[i]
	
		######################################################################################
	
		#print("Calculation of CpGs having interaction with", i)	
		if i in Int2.index.tolist():
			#print("Yes CPG FOR ", i)
			##################################################################################
			if isinstance(Int2.loc[i]["CpG"], str) == True:
				CpG_list =[]
				CpG_list.append(Int2.loc[i]["CpG"])
			else:
				CpG_list = Int2.loc[i]["CpG"].tolist()
	
			## check in miRNA expression file
			for j in CpG_list:
				if j in methyl.index.tolist():
					meth = methyl.loc[j]
					meth_exp = pd.Series(meth.apply(lambda x : 1/math.e ** (1.5*(math.log(x+1,2))))).mul(mrna_temp)
					df = pd.concat([df, meth_exp], axis = 1).mean(axis=1)
				else:
					None
		else:
			#print("NO CPG FOR", i)
			df = mrna_temp
		delta2 = pd.concat([delta2, df], axis = 1)
		#print(i)
		#print(delta2.shape)
	delta2.columns = [mrna_list]
	return delta2