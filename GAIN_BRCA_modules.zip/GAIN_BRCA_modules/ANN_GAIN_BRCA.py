import tensorflow as tf
from tensorflow import keras
import pandas as pd
from sklearn.model_selection import StratifiedKFold
import numpy as np
import statistics
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import accuracy_score
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import f1_score
from sklearn.metrics import cohen_kappa_score
from sklearn.metrics import roc_auc_score
from sklearn.metrics import confusion_matrix


def ANN(X, y, n_loops):
	
	# feature dimensions
	feature_dim = len(X.axes[1])

	#Data scaling & Assign header and row in dataset & rounding off up to 3 decimals
	row = X.index.tolist()
	header = X.columns.values.tolist()
	X = pd.DataFrame(MinMaxScaler().fit_transform(X)).set_axis(row, axis=0).set_axis(header, axis=1).to_numpy()

	# Import_dependent_variables and convert to numpy array
	n_classes = len(np.unique(y))

	# Numpy conversion
	y = y.to_numpy()
	n_loops = 50
	acc_list_master = []
	avg_acc_list = []
	a = []
	for i in range (n_loops):
		kfold = StratifiedKFold(n_splits=5, shuffle=True)
		cvscores = []
	
		test_acc_list = []
		for train, test in kfold.split(X, y):
			model = keras.Sequential([
			keras.layers.Dense(300, input_shape = (feature_dim,), activation = "relu"),
			keras.layers.Dense(100, activation = "relu"),
			keras.layers.Dense(25, activation = "relu"),
			keras.layers.Dense(n_classes, activation = "softmax")])
		
			#print("######_Model Compilation_Starts_######")
			model.compile(optimizer = "adam",loss = "sparse_categorical_crossentropy", metrics=["accuracy"])
		
			#print("######_Model_Training_Accuracy_######")
			model.fit(X[train], y[train], epochs=100, batch_size=10, verbose=2)
		
			#print("######_Model_Evaluation_Accuracy_######")
			scores = model.evaluate(X[test], y[test], verbose=0)
			print("%s: %.2f%%" % (model.metrics_names[1], scores[1]*100))
			cvscores.append(scores[1] * 100)
			print("%.2f%% (+/- %.2f%%)" % (np.mean(cvscores), np.std(cvscores)))
		
			yhat_probs = pd.DataFrame(model.predict(X[test], verbose=2))
			y_pred = yhat_probs.idxmax(axis=1)
	
			from sklearn.metrics import confusion_matrix , classification_report, accuracy_score

			Accuracy = accuracy_score(y[test],y_pred)
	
			test_acc_list.append(Accuracy)
			acc_list_master.append(Accuracy)
			
		avg_test_acc = statistics.mean(test_acc_list)
		test_acc_list.append(avg_test_acc)
		a.append(test_acc_list)

	final_acc = max(acc_list_master)
	return acc